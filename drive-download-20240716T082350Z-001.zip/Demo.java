public class Demo{
	public static void main(String[] args){
		
	int nums[]={4,7,2,6};
	System.out.println(nums.length);
	}
}