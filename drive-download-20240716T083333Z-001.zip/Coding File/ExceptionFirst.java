// Syntax error
public class ExceptionFirst
	{
	public static void main(String[] args)
	{
		System.out.printn();
	}
}