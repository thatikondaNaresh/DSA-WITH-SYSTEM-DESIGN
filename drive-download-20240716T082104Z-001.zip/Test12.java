Class Test12
{
	int a;
	String name;
	Public static void main(String args[]){
	// declare the variable
	// create the object
	int num=9;
	Test obj=new Test();
	}
}
