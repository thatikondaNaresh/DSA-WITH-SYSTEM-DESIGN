public class Demo1{
	public static void main(String[] args){
		int nums[]={5,4,7,2};
		
			for(int i=0;i<=3;i++)
			{
				System.out.println(nums[i]);
			}
		}
}