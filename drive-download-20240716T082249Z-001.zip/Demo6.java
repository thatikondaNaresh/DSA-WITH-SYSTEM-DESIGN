public class Demo6{
	public static void main(String[] args){
	
		int nums[][]={
					{3,9,7,5},
					{1,5,6,5},
					{8,4,5,6}
				};
		for(int i=0;i<=2;i++)
		{
			for(int j=0;j<=3;j++)
			{
				System.out.print(nums[i][j]+ " ");

			}
			System.out.println();
		}
	}
}