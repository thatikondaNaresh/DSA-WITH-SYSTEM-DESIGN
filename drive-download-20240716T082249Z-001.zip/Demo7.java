// For-each
public class Demo7{
	public static void main(String[] args){
	
		int nums[]={5,8,4,3};
		for(int n:nums)
		{
			System.out.println(n);
		}
	}
}














